<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "almacenes";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Procesar el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = $_POST["usuario"];
    $contrasena = $_POST["contrasena"];

    // Obtener el máximo valor actual de Almacen_id y sumarle 1
    $result = $conn->query("SELECT MAX(Almacen_id) AS max_id FROM usuario");
    $row = $result->fetch_assoc();
    $nuevo_almacen_id = ($row["max_id"] !== null) ? $row["max_id"] + 1 : 1;

    $sql = "INSERT INTO usuario (nombre, Password, Almacen_id) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $usuario, $contrasena, $nuevo_almacen_id);

    if ($stmt->execute()) {
        echo "<div style='text-align:center; margin-top:40px; font-size:1.2em; color:green; background:#eafbe7; border-radius:8px; padding:20px; box-shadow:0 2px 8px rgba(0,0,0,0.07);'>";
        echo "<strong>✔ Usuario guardado exitosamente.</strong>";
        echo "</div>";
        echo "<div style='text-align:center; margin-top:20px;'><a href='../registrar.html' style='text-decoration:none; color:#fff; background:#2a3d66; padding:10px 24px; border-radius:6px;'>Volver</a></div>";
    } else {
        echo "<div style='text-align:center; margin-top:40px; font-size:1.2em; color:red; background:#fdeaea; border-radius:8px; padding:20px; box-shadow:0 2px 8px rgba(0,0,0,0.07);'>";
        echo "<strong>✖ Error al guardar el usuario.</strong>";
        echo "</div>";
    }
    $stmt->close();
}

$conn->close();
?>
